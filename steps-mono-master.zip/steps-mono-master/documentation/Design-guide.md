# Design Guide

## Collaborate

To participate to the design of this font, you can fork the project and make a pull request.
Do not forget to browse the content of the /documentation folder.
Please open an issue if you have any question about the project.

## Webfont

Generate Webfonts using [Fontsquirrel generator](http://www.fontsquirrel.com/tools/webfont-generator) or a similar convertor. Chose “No Subsetting” in expert mode in order to include all the glyphs of the font.
