Copyright (c) 2013-2014, Raphaël Bastide <bonjour@raphaelbastide.com>
Copyright (c) 2013-2014, Jean-Baptiste Morizot <jbmorizot@gmail.com>
